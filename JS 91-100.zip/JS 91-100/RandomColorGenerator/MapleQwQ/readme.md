# Random Color Generate

This is a simple project that generates random colors, and you can also choose the RGB to generate the color you want.



