# Random-Color-Generator
This is a JS project that generates random colour with its RGB value shown on the screen.
A reset feature has also been added to reset the colour to original color.
  
  ## Tutorial Links to follow:-
  ### Git and Github
  https://youtu.be/apGV9Kg7ics
