## Random Color Palette Generator

screenshot:

![Alt text](<Screenshot (113).png>)